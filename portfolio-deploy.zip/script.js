document.addEventListener('DOMContentLoaded', () => {
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    
    // Check local storage or preference
    const savedTheme = localStorage.getItem('theme');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemDark)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        updateToggleIcon(true);
    }

    themeToggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateToggleIcon(newTheme === 'dark');
    });

    function updateToggleIcon(isDark) {
        themeToggle.textContent = isDark ? '☀️' : '🌙';
    }

    // Smooth Scrolling for Anchors
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Reveal Animations on Scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px"
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.project-card, .stat-card, .skill-col, .contact-layout').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Contact Form Handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBtn');
            const spinner = document.getElementById('spinner');
            const btnText = submitBtn.querySelector('span');
            const formMessage = document.getElementById('formMessage');
            
            // Show Spinner
            submitBtn.disabled = true;
            spinner.style.display = 'block';
            btnText.style.opacity = '0';
            formMessage.textContent = '';
            
            const formData = new FormData(contactForm);
            
            try {
                // Simulate network delay for effect (optional, or just go straight to fetch)
                // await new Promise(r => setTimeout(r, 1000));

                const response = await fetch('/', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams(formData).toString()
                });
                
                if (response.ok) {
                    formMessage.className = 'form-message text-success';
                    formMessage.textContent = "Thanks! Message sent to yashjiotode19@gmail.com";
                    contactForm.reset();
                } else {
                    throw new Error('Form submission failed');
                }
            } catch (error) {
                // In local dev, fetch('/') might fail or return 404, but let's assume success for demo if needed
                // For now, standard error handling:
                formMessage.className = 'form-message text-error';
                formMessage.textContent = "Oops! Something went wrong. Please try again.";
                console.error(error);
            } finally {
                // Hide Spinner
                submitBtn.disabled = false;
                spinner.style.display = 'none';
                btnText.style.opacity = '1';
            }
        });
    }
});
